export {default as NavBar} from './NavBar/NavBar';
export {default as Footer} from './Footer/Footer';
export {default as Hero} from './Hero/Hero';
export {default as AddTemplate} from './AddTemplate/AddTemplate'
export {default as GetFile} from './GetFile/GetFile'